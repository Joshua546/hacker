(function($) {
    checkboxAssociations('.toggle-checkboxAction:checkbox','.toggle-action:checkbox');
})(jQuery);
